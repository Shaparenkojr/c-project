﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;
// Тема: #1 Заказы в кафе

// Задание:
// Создать программу по управлению объектами данных по указанной теме с  использованием ООП и реализовывать изученные паттерны.
// Необходимо создать минимум 3 объекта сущности разных видов и указать взаимодействие между объектами.Реализовать интерфейсы ввод,
// вывода и редактитрвоания сущьностей.Реализовать ручной ввод сущностей, загрузку из файла и сохранения в файл, удаление выбранных сущностей.
// Данные между запусками программы хранить в структурированном текстовом файле.



// Блюдо
class Product {
protected:
    string name;
    int cost;
public:
    Product() { name = "\t"; cost = 0;}
    void create(const string n, const int c) { name = n; cost = c; }
    string getName() { return name; }
    int getCost() { return cost; }
};

// Фабрика
class fabrikaA {
public:
    Product* create(string* mas) {
        Product* res = new Product;
        res->create(mas[0], stoi(mas[1]));
        return res;
    }
};

// Заказ
class Order {
protected:
    fabrikaA store;
    int id = 10;
    int countItems = 0;
    Product* items[100] = { 0 };
    string Clientname, tbNumber;

public:
    int getID() { return id; }
    int getCount() { return countItems; }
    Product** getItems() { return items; }
    string getName() { return Clientname; }
    string gettbNumber() { return tbNumber; }

    void create(const string n, const string tb, const int count, string(*ms)[2], const int id_in) {
        if (id_in != 0) id = id_in;
        Clientname = n;
        tbNumber = tb;
        for (int i = 0; i < count; i++) {
            items[i] = store.create(ms[i]);
            countItems++;
        }
    }
    void printOrder() {
        cout << id << endl;
        cout << '\t' << Clientname << endl;
        cout << '\t' << tbNumber << endl;
        for (int i = 0; i < countItems; i++) {
            cout << "\t\t" << items[i]->getName() << " : " << items[i]->getCost() << endl;
        }
    }
};


class fabrikaB {
public:
    Order* create(const string n, const string tb, const int count, string(*ms)[2], const int id) {
        Order* res = new Order;
        res->create(n, tb, count, ms, id);
        return res;
    }
};

class cassir {
private:
    fabrikaB store;
    Order* orders[100] = {};
    int countOrders = 0;

public:
    int getCount() { return countOrders; }
    Order** getOrders() { return orders; }

    void printOrders() {
        for (int i = 0; i < countOrders; i++) {
            cout << '[' << i + 1 << "] ";
            orders[i]->printOrder();
        }
    }
    void newOrder(const string n, const string tb, const int count, string(*ms)[2], const int id = 0) {
        orders[countOrders] = store.create(n, tb, count, ms, id);
        countOrders++;
    }
    void delOrder(const int ind) {
        if ((ind >= 0) && (ind < countOrders)) {
            for (int i = ind; i < countOrders - 1; i++) { orders[i] = orders[i + 1]; }
            countOrders--;
        }
    }
};

// Меню 
class Goodctrl {
private:
    int choice1 = 0;
    int kg = 0;
    cassir* Cassir = new cassir;


    void mainMenu(void) {
        system("cls");
        cout << "Главное меню\n";
        cout << "Все названия должны быть на английском языке\n\n";
        cout << "[1] Показать заказы\n";
        cout << "[2] Новый заказ\n";
        cout << "[3] Удалить из списка\n";
        cout << "[4] Сохранить в файл\n";
        cout << "[5] Взять из файла\n";
        cout << "[0] Выйти\n";
        cout << "Выбор: ";
        cin >> choice1;
    }

    // Вывод всех заказов в консоль
    void print() {
        system("cls");
        Cassir->printOrders();
        cout << "Введите 0 для продолжения:";
        cin >> kg;
    }

    // Создание нового заказа
    void newOrderMenu(void) {
        string c, name, tbNum;
        string mas[100][2];
        system("cls");
        cout << "Введите имя клиента - ";
        getline(cin >> ws, name);
        cout << "Введите номер столика - ";
        getline(cin >> ws, tbNum);
        cout << "Введите колличество пунктов заказа - ";
        getline(cin >> ws, c);
        for (int i = 0; i < stoi(c); i++) {
            cout << "Название блюда - ";
            getline(cin >> ws, mas[i][0]);
            cout << "Цена - ";
            getline(cin >> ws, mas[i][1]);
        }
        Cassir->newOrder(name, tbNum, stoi(c), mas);

        cout << "Выполнено\n";
        cout << "Введите 0 для продолжения: ";
        cin >> kg;
    }

    // Удаление заказа
    void removeOrderMenu(void) {
        string c;
        system("cls");
        cout << "Меню удаления заказа\n\n";
        cout << "[0] Назад\n";
        Cassir->printOrders();
        cout << "Пожалуйста выберете заказ: ";
        getline(cin >> ws, c);
        Cassir->delOrder(stoi(c) - 1);
        system("cls");
        cout << "Выполнено успешно" << endl;
        cout << "Введите 0 для продолжения";
        cin >> kg;
    }

    // Сохранение данных в файл "base.txt"
    void saveToFile() {
        ofstream fout;
        string path = "base.txt";
        fout.open(path);
        if (!fout.is_open()) {
            cout << "Ошибка открытия файла" << endl;
        }
        else {
            Order** ord = Cassir->getOrders();
            fout << Cassir->getCount() << '\n'; // количество клиентов
            for (int i = 0; i < Cassir->getCount(); i++) {
                fout << ord[i]->getID() << '\n'; // номер заказа
                fout << ord[i]->getName() << '\n'; // имя клиента
                fout << ord[i]->gettbNumber() << '\n'; // номер клиента
                fout << ord[i]->getCount() << '\n'; // количество пунктов в заказе
                Product** prod = ord[i]->getItems();
                for (int j = 0; j < ord[i]->getCount(); j++) {
                    fout << prod[j]->getName() << endl; // название товара
                    fout << prod[j]->getCost() << endl; // цена блюда
                }
            }
            system("cls");
            cout << "Выполнено успешно" << endl;
            cout << "Введите 0 для продолжения";
            cin >> kg;
        }
        fout.close();
    }

    // Импорт из файла "base.txt"
    void takeFromFile() {
        ifstream fin;
        string str, id, nm, tb, cnt, path = "base.txt";
        string mas[100][2];
        fin.open(path);
        if (!fin.is_open()) {
            cout << "Ошибка открытия файла" << endl;
        }
        else {
            getline(fin, str, '\n');
            int ordersCount = stoi(str);
            for (int i = 0; i < ordersCount; i++) {
                getline(fin, id, '\n');
                getline(fin, nm, '\n');
                getline(fin, tb, '\n');
                getline(fin, cnt, '\n');
                int itemsCount = stoi(cnt);
                for (int j = 0; j < itemsCount; j++) {
                    getline(fin, mas[j][0], '\n');
                    getline(fin, mas[j][1], '\n');
                }
                Cassir->newOrder(nm, tb, stoi(cnt), mas, stoi(id));
            }
            system("cls");
            cout << "Complete!" << endl;
            cout << "Enter 0 to continue:";
            cin >> kg;
        }
        fin.close();
    }

public:
    void menu() {
        do {
            mainMenu();
            switch (choice1) {
            case 1:
                print();
                break;
            case 2:
                newOrderMenu();
                break;
            case 3:
                removeOrderMenu();
                break;
            case 4:
                saveToFile();
                break;
            case 5:
                takeFromFile();
                break;
            case 0:
                break;
            }
        } while (choice1 != 0);
    }
};

int main()
{
    setlocale(LC_ALL, "Russian");
    Goodctrl ctrl;
    ctrl.menu();

    return 0;
}